"""Example script for tutorial Advanced custom model: A screw pull-out test

This script creates from scratch a cantilever beam model with an applied force
on the end of the beam.

Refer to the FAIM manual for description and use of this example script.

Copyright 2012-2016, Numerics88 Solutions Ltd.

You may freely copy, modify and share this script.
"""

from __future__ import division
import os
import sys
import time
import vtk
import vtkbone

script_version = 8


# -------------------------------------------------------------------------
#  Utility functions

def message(msg, *additionalLines):
    """Print message with time stamp.
    
    The first argument is printed with a time stamp.
    Subsequent arguments are printed one to a line without a timestamp.
    """
    print "%8.2f %s" % (time.time()-start_time, msg)
    for line in additionalLines:
        print " " * 9 + line
start_time = time.time()


# -------------------------------------------------------------------------
#  Configuration

if len(sys.argv) != 2:
  print "Usage: python screwpullout.py example.conf"
  sys.exit(1)
config_file = sys.argv[1]

# Read in configuration file.
message("Reading configuration file " + config_file)
# Here we are actually executing it as python code.
execfile(config_file)

# Print out values that we read in. This also has the effect of causing
# this script to die if configuration values are missing (which is a good thing).
settings_text = ["Configuration:"]
settings_text.append( "input file                     = %s" % input_image_file)
settings_text.append( "output file                    = %s" % n88model_file)
settings_text.append( "bone material id               = %s" % bone_material_id)
settings_text.append( "bone material Young's modulus  = %s" % bone_material_modulus)
settings_text.append( "bone material Poisson's ratio  = %s" % bone_material_poissons_ratio)
settings_text.append( "screw material id              = %s" % screw_material_id)
settings_text.append( "screw material Young's modulus = %s" % screw_material_modulus)
settings_text.append( "screw material Poisson's ratio = %s" % screw_material_poissons_ratio)
settings_text.append( "screw displacement             = %s" % screw_displacement)
settings_text.append( "inner ring radius              = %s" % inner_ring_radius)
settings_text.append( "bone constraint max depth      = %s" % bone_constraint_max_depth)
message(*settings_text)


# -------------------------------------------------------------------------
# Read input data

message("Reading input data.")
reader = vtkbone.vtkboneAIMReader()
reader.SetFileName(input_image_file)
reader.DataOnCellsOn()
reader.Update()
image = reader.GetOutput()
message("Read %d points from image file." % image.GetNumberOfPoints())
image_bounds = image.GetBounds()
message("Image bounds:", (" %.4f"*6) % image_bounds)


# -------------------------------------------------------------------------
# Convert the 3D image data to hexahedral cells

message("Converting to hexahedral cells.")
mesher = vtkbone.vtkboneImageToMesh()
mesher.SetInputData(image)
mesher.Update()
mesh = mesher.GetOutput()
message("Generated %d hexahedrons" % mesh.GetNumberOfCells())


# --------------------------------------------------------------------------
# Create a material table.

message ("Creating material table.")
material_table = vtkbone.vtkboneMaterialTable()

# Create an isotropic material for bone and add it to the table.
bone_material = vtkbone.vtkboneLinearIsotropicMaterial()
bone_material.SetName("bone")
bone_material.SetYoungsModulus(bone_material_modulus)
bone_material.SetPoissonsRatio(bone_material_poissons_ratio)
material_table.AddMaterial(bone_material_id, bone_material)

# Create an isotropic material for the screw and add it to the table.
screw_material = vtkbone.vtkboneLinearIsotropicMaterial()
screw_material.SetName("screw")
screw_material.SetYoungsModulus(screw_material_modulus)
screw_material.SetPoissonsRatio(screw_material_poissons_ratio)
material_table.AddMaterial(screw_material_id, screw_material)


# -------------------------------------------------------------------------
# We pass the data through vtkboneFiniteElementModelGenerator to create a
# vtkboneFiniteElementModel object. vtkboneFiniteElementModelGenerator is a base class that
# doesn't create any boundary conditions or applied loads, and does not
# create any pre-defined sets.

message("Constructing a finite element model object.")
generator = vtkbone.vtkboneFiniteElementModelGenerator()
generator.SetInputData(0, mesh)
generator.SetInputData(1, material_table)
generator.Update()
model = generator.GetOutput()
model.ComputeBounds()
bounds = model.GetBounds()
message("Model bounds:", (" %.4f"*6) % bounds)

# Add some History and Log data to the model

model.AppendHistory("Created by screwpullout.py version %s ." % script_version)

model.AppendLog(
"""screwpullout.py
Model of screw being pulled out of bone substitute material.
Using vtkbone version %s .
Configuration file : %s
""" % (vtkbone.vtkboneVersion.GetVTKBONEVersion(), config_file)
+ "\n".join(settings_text))


# --------------------------------------------------------------------------
# Determine screw geometry

message("Determining screw geometry.")

moi = vtkbone.vtkboneTensorOfInertia()
moi.SetInputData(image)
moi.SetSpecificValue(screw_material_id)
moi.Update()
message("Number of cells belonging to screw: %d" % moi.GetCount())
message("Volume of screw: %.2f" % moi.GetVolume())
screwCenterOfMass = (moi.GetCenterOfMassX(),
                     moi.GetCenterOfMassY(),
                     moi.GetCenterOfMassZ())
message("Center of mass of screw: %.5f, %.5f, %.5f" % screwCenterOfMass)
screwAxis = moi.GetPrincipalAxisClosestToZ()
message("Axis of screw: %.5f, %.5f, %.5f" % screwAxis)
screwDistanceToBoundary = (bounds[5] - screwCenterOfMass[2]) / screwAxis[2]
screwCenterAtBoundary = (
    screwCenterOfMass[0] + screwDistanceToBoundary * screwAxis[0],
    screwCenterOfMass[1] + screwDistanceToBoundary * screwAxis[1],
    bounds[5])
message("Distance from screw center of mass to boundary: %.3f" % screwDistanceToBoundary)
message("Screw center at boundary: %.3f, %.3f, %.3f" % screwCenterAtBoundary)


# --------------------------------------------------------------------------
# Constraint 1: Apply a displacement boundary condition to the screw top

message("Adding the screw_top boundary condition.")

# The following line finds all nodes that have z coordinate (the value
# 2 = z axis) equal to bounds[5], which is the top surface, and also
# have material ID screw_material_id (this may not actually be necessary,
# since no elements of other material types intersect the  z=0 surface).
# It creates a new node sets with name "screw_top".
vtkbone.vtkboneNodeSetsByGeometry.AddNodesOnPlane(
    2,
    bounds[5],
    "screw_top",
    model,
    screw_material_id)
message("Found %d nodes belonging to screw_top" % 
     model.GetNodeSet("screw_top").GetNumberOfTuples())

# Create a boundary condition that is applied to the node set. This constraint
# means displacement along the z axis (2 = z axis) by the value 'displacement'.
model.ApplyBoundaryCondition(
    "screw_top",
    2,
    screw_displacement,
    "screw_top_displacement")


# --------------------------------------------------------------------------
# Constraint 2: Apply a fixed boundary condition in a ring to the top surface of bone.
#
# We want to find the bone nodes, in a ring of a certain radius, that you
# would be able to see if you looked down upon the image from above.
# Further, we are going to limit the depth of nodes that we accept, where
# the depth is measured from the highest such node that we see.

message("Adding the fixed_bone_surface boundary condition.")

# As the first step, we extract all elements that are in a cylindrical volume
# with the correct radii.
# Will we will use the subtraction of 2 cylinders.
# Cylinders are aligned along the y axis by default, so we need a rotation
# transformation. Note that the transformation will be applied to input
# points, not to the cylinder geometry.
inner_cylinder = vtk.vtkCylinder()
inner_cylinder.SetRadius(inner_ring_radius)
# Note that the center is swapped y <-> z because of the transform applied to
# input points
inner_cylinder.SetCenter(screwCenterAtBoundary[0], 0, screwCenterAtBoundary[1])

outer_cylinder = vtk.vtkCylinder()
outer_cylinder.SetRadius(outer_ring_radius)
outer_cylinder.SetCenter(screwCenterAtBoundary[0], 0, screwCenterAtBoundary[1])

rotate_Y_to_Z = vtk.vtkTransform()
rotate_Y_to_Z.RotateX(90)

cylinder_difference = vtk.vtkImplicitBoolean()
cylinder_difference.AddFunction(outer_cylinder)
cylinder_difference.AddFunction(inner_cylinder)
cylinder_difference.SetOperationTypeToDifference()
cylinder_difference.SetTransform(rotate_Y_to_Z)

cylinder_extractor = vtk.vtkExtractGeometry()
cylinder_extractor.SetImplicitFunction(cylinder_difference)
cylinder_extractor.SetInputData(model)
cylinder_extractor.Update()
geometry_in_ring = cylinder_extractor.GetOutput()

message("Found %d elements between inner and outer radii." % geometry_in_ring.GetNumberOfCells())

# Note: geometry_in_ring does NOT have the original Points list.
#       However, it does have a PointData attribute PedigreeIds array.
#       This point data stays associated with points through manipulations
#       (such as vtkExtractGeometry) so at the end we will still be able
#       to identify node Ids.

# Optional: Create an element set so we can visualize this selection.
# Note: An alternative would be to use a vtkXMLUnstructuredGridWriter
#       to write out geometry_in_ring.
elements_in_ring = vtk.vtkIdTypeArray()
elements_in_ring.DeepCopy(geometry_in_ring.GetCellData().GetPedigreeIds())
elements_in_ring.SetName("in_ring")
model.AddElementSet(elements_in_ring)

message("Filtering node set by depth.")

geometry_in_ring_bounds = geometry_in_ring.GetBounds()
message("Bounds of ring geometry: ", (" %.4f"*6) % geometry_in_ring_bounds)
box_bounds = (geometry_in_ring_bounds[0],
              geometry_in_ring_bounds[1],
              geometry_in_ring_bounds[2],
              geometry_in_ring_bounds[3],
              geometry_in_ring_bounds[5] - bone_constraint_max_depth,
              geometry_in_ring_bounds[5])
message("Limiting selection to box bounds: ", (" %.4f"*6) % box_bounds)

box = vtk.vtkBox()
box.SetBounds(box_bounds)

filter = vtk.vtkExtractGeometry()
filter.SetImplicitFunction(box)
filter.ExtractInsideOn()
filter.ExtractBoundaryCellsOn()
filter.SetInputData(geometry_in_ring)
filter.Update()
geometry_depth_filtered_ring = filter.GetOutput()

message("Found %d elements in bounding box." % geometry_depth_filtered_ring.GetNumberOfCells())

# Optional: Create an element set so we can visualize this selection.
elements_depth_filtered_ring = vtk.vtkIdTypeArray()
elements_depth_filtered_ring.DeepCopy(geometry_depth_filtered_ring.GetCellData().GetPedigreeIds())
elements_depth_filtered_ring.SetName("depth_filtered_ring")
model.AddElementSet(elements_depth_filtered_ring)

message("Finding visible nodes.")

visibleNodesIds = vtk.vtkIdTypeArray()
normalVector = (0,0,1)
# Note: Because geometry_depth_filtered_ring contains Pedigree Ids, those will
#       be returned by FindNodesOnVisibleSurface.
vtkbone.vtkboneNodeSetsByGeometry.FindNodesOnVisibleSurface(
  visibleNodesIds,
  geometry_depth_filtered_ring,
  normalVector,
  bone_material_id)
visibleNodesIds.SetName("ring_top_visible")
model.AddNodeSet(visibleNodesIds)

message("Found %d visible nodes." % visibleNodesIds.GetNumberOfTuples())

# Create a boundary condition that is applied to ring_top_visible.
model.FixNodes("ring_top_visible", "fixed_bone_surface")

# --------------------------------------------------------------------------
# Create a convergence set: the force on the screw

model.ConvergenceSetFromConstraint("screw_top_displacement")

# --------------------------------------------------------------------------
# Set the post-processing parameters

# Set the node sets and element sets that will be used for post-processing
info = model.GetInformation()
pp_node_sets_key = vtkbone.vtkboneSolverParameters.POST_PROCESSING_NODE_SETS()
pp_elem_sets_key = vtkbone.vtkboneSolverParameters.POST_PROCESSING_ELEMENT_SETS()
for setname in ["ring_top_visible", "screw_top"]:
    # Specify that these sets should be used for post-processing
    pp_node_sets_key.Append(info, setname)
    # n88postfaim requires that each node set requires a matching element set
    elementSet = model.GetAssociatedElementsFromNodeSet(setname)
    model.AddElementSet(elementSet)
    pp_elem_sets_key.Append(info, setname)


# --------------------------------------------------------------------------
# Write an n88model file.

message("Writing file %s" % n88model_file)
writer = vtkbone.vtkboneN88ModelWriter()
writer.SetInputData(model)
writer.SetFileName(n88model_file)
writer.Update()

message("Done.")

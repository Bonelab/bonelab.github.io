"""Example script for Tutorial: Compressing a cube revisited using vtkbone

This script creates a compression test on an input file (typically cube6x6x6.vti, which
can be found in the data directory.)

Refer to the FAIM manual for description and use of this example script.

Copyright 2012-2016, Numerics88 Solutions Ltd.

You may freely copy, modify and share this script.
"""

from __future__ import division
import argparse
import os
import sys
import vtk
import vtkbone

script_version = 3

# Get the command line arguments

parser = argparse.ArgumentParser (
    description="""Apply a compression test.
This script does essentially the same as the command
"n88modelgenerator --test=uniaxial"
but uses vtkbone for this purpose.
""")

parser.add_argument ("input_file",
   help="An input image file of the segmented data; must be in VTK XML format (.vti).")

args = parser.parse_args()

# Read input image of segmented data.

print "Reading", args.input_file
reader = vtk.vtkXMLImageDataReader()
reader.SetFileName(args.input_file)
reader.Update()
image = reader.GetOutput()

if not image:
    print "No image data read."
    sys.exit(1)

print "Read image with point dimensions", image.GetDimensions()

print "Applying connectivity filter."
connectivity_filter = vtkbone.vtkboneImageConnectivityFilter()
connectivity_filter.SetExtractionModeToLargestRegion()
connectivity_filter.SetInputData(image)
connectivity_filter.Update();
image = connectivity_filter.GetOutput()

# Generate a finite element mesh from the input image

geometry_generator = vtkbone.vtkboneImageToMesh()
geometry_generator.SetInputData(image)
geometry_generator.Update()
geometry = geometry_generator.GetOutput()

print "Generated %d elements and %d nodes." % \
      (geometry.GetNumberOfCells(), geometry.GetNumberOfPoints())

# Optional - Uncomment the following lines to create a .vtu file of the
#            geometry.  It can be opened and rendered with ParaView.

# writer = vtk.vtkXMLUnstructuredGridWriter()
# geometry_file = "geometry.vtu"
# print "Writing geometry to", geometry_file
# writer.SetFileName(geometry_file)
# writer.SetInputData(geometry)
# writer.Write()

# Define material Properties

print "Creating a linear isotropic material."
material = vtkbone.vtkboneLinearIsotropicMaterial()
material.SetName("linear_iso_material")
material.SetYoungsModulus(6829)
material.SetPoissonsRatio(0.3)

mt_generator = vtkbone.vtkboneGenerateHomogeneousMaterialTable()
mt_generator.SetMaterial(material)
mt_generator.SetMaterialIdList(image.GetCellData().GetScalars())
mt_generator.Update()
material_table = mt_generator.GetOutput()
print "Generated material table with %d entries." % material_table.GetNumberOfMaterials()

# Apply a compression test (uniaxial)

print "Applying a uniaxial compression test."
generator = vtkbone.vtkboneApplyCompressionTest()
generator.SetInputData(0, geometry)
generator.SetInputData(1, material_table)
generator.Update()
model = generator.GetOutput()

model.AppendHistory("Created by cube_compression.py version %s ." % script_version)

# Write an n88model file

output_file = os.path.splitext(args.input_file)[0] + "_custom.n88model"
# Remove directory, so file ends up in current directory.
output_file = os.path.split(output_file)[1]

print "Writing n88model file:", output_file
writer = vtkbone.vtkboneN88ModelWriter()
writer.SetInputData(model)
writer.SetFileName(output_file)
writer.Update()

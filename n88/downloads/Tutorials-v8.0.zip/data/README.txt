Example data files for Numerics88 software
==========================================

radius_slice82.aim:
  A micro-CT scan of a slice of an ultra distal radius bone. The bone has
  been segmented with ID 127. Image resolution is 82 microns and the 
  dimensions are 325,437,110.  This data file is used in the tutorial
  "Compression test of a radius bone slice".

radius_slice164.aim:
  A reduced-resolution version of radius_slice82.aim, with resolution
  164 microns and size 163,219,55.

radius82.aim:
  A micro-CT scan of an ultra distal radius bone. The bone has
  been segmented with ID 127. Image resolution is 82 microns and the 
  dimensions are 400,350,1100.  This data file is used in the tutorial
  "Bending test of a radius bone with an uneven surface".

radius164.aim:
  A reduced-resolution version of radius82.aim, with resolution
  164 microns and size 200,175,550.

aluminum_foam.vti:
  A micro-CT scan of aluminum foam which has an interesting structure similar
  to trabecular bone. The aluminum material has been segmented with ID 127.
  Note that not all the aluminum material is connected in one object (i.e. no
  component filtering was done), therefore if preparing models with
  n88modelgenerator, the --connectivity_filter=on filter should be used. Image
  dimensions are 300,136,87.

sawbone.aim:
  A scan of sawbone material with an embedded screw.  The sawbone material
  has been segmented with ID 127, and the screw with ID 90.  Image dimensions
  are 136,135,309.  This data file is used in the tutorial "Advanced custom
  model tutorial: a screw pull-out test".

test25a.aim:
  A small extract of micro-CT scan of trabecular bone, with dimensions
  25,25,25. The bone has been segmented with ID 127.  This data set is small
  enough to solve very quickly on any system, yet is not completely trivial.

quasidonut.vti:
  A small data set with dimensions 5,5,3.  The surface is uneven.  Two
  different material IDs are used, 127 and 100.  This is useful for
  simple testing of the software.

1x1x2.vti:
  A tiny data set with dimensions 1,1,2.  Both cells have value 127.  This is
  occasionally useful for trouble-shooting.


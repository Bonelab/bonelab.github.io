Files for the tutorials from the Faim manual
============================================

Refer to the Faim manual at http://numerics88.com/documentation/faim/8.0/

Note that the data files are in the directory `data`. These directories
contain scripts and configuration files.

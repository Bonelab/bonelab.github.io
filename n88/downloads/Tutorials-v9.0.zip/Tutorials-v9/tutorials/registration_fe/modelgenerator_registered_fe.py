# Template script for Tutorial 7.9 (before additional examples)

# Packages to import:
import os
import sys
import argparse
import numpy as np
import vtk
import vtkbone

# Optional packages:
import time

# Optional function to generate messages with a time stamp:
def message(msg, *additionalLines):
    """Print message with time stamp.

    The first argument is printed with a time stamp.
    Subsequent arguments are printed one to a line without a time stamp.
    """

    print(('{0:8.2f} {1:s}'.format(time.time() - start_time, msg)))
    for line in additionalLines:
        print((" " * 9 + line))

# Start runtime for time stamps:
start_time = time.time()

# Reading material file:
def ReadMaterialFile(material_file):
    bone_name = 'Bone'
    surface_name = 'Surface'
    bone_material_id = 125
    surface_material_id = 127

    with open(material_file, encoding = 'cp1250') as searchfile:
        for line in searchfile:
            front = line.split(':')[0]
            if ("E" in front):
                bone_modulus = float(line.split(':')[1]) # E = 8748 MPa
                surface_modulus = bone_modulus
            if ("nu" in front):
                bone_poissons_ratio = float(line.split(':')[1]) # v = 0.3
                surface_poissons_ratio = bone_poissons_ratio

    return bone_name, bone_material_id, bone_modulus, bone_poissons_ratio, \
    surface_name, surface_modulus, surface_poissons_ratio, surface_material_id

# Model generator function (in place of n88modelgenerator):
def CreateN88Model(input_file, output_file, material_file, transform_file, overwrite, displacement):

    # Optional file checks ---
    # Ask the user if output_file should be overwritten:
    if os.path.isfile(output_file) and not overwrite:
        result = eval(input('File \"{}\" already exists. Overwrite? [y/n]: '.format(output_file)))
        if result.lower() not in ['y', 'yes']:
            print('Not overwriting. Exiting...')
            os.sys.exit()
    # Check that input_file exists:
    if not os.path.isfile(input_file):
        os.sys.exit('[ERROR] File \"{}\" not found!'.format(input_file))

    # Read input_file (i.e. *_REG_HOM_LS.AIM from XtremeCT II)
    message("Reading AIM file " + input_file + " as input...")
    reader = vtkbone.vtkboneAIMReader()
    reader.SetFileName(input_file)
    reader.DataOnCellsOn()
    reader.Update()

    image = reader.GetOutput()
    # Check that input_file is read correctly:
    if not reader.GetOutput():
        message("[ERROR] No image data read!")
        sys.exit(1)
    # Report image size (bounds):
    message("Image bounds:", (" %.4f" * 6) % image.GetBounds())

    # Read transformation matrix from 3D image registration in IPL:
    if os.path.isfile(transform_file):
        message("Reading IPL transformation matrix...")
        if(transform_file):
            t_mat = np.loadtxt(fname = transform_file, skiprows = 2)
            rotation = t_mat[:3, :3]
    else:
        message("[WARNING] No transformation matrix applied, identity used instead...")
        rotation = np.identity(3)

    if os.path.isfile(material_file):
        bone_name, bone_material_id, bone_modulus, bone_poissons_ratio, \
        surface_name, surface_modulus, surface_poissons_ratio, surface_material_id \
        = ReadMaterialFile(material_file)
    # Report error if file is missing or not read correctly:
    else:
        message("[ERROR] No material data read!")
        sys.exit(1)
    # Report material properties so the user can check values:
    message('Material attributes:',
    '{:16s} = {:>8s}'.format('Material name', bone_name),
    '   {:14s} = {:8d}'.format('ID', bone_material_id),
    '   {:14s} = {:8.2f} MPa'.format('Modulus', bone_modulus),
    '   {:14s} = {:8.2f}'.format('Poissons ratio', bone_poissons_ratio),
    '{:16s} = {:>8s}'.format('Material name', surface_name),
    '   {:14s} = {:8d}'.format('ID', surface_material_id),
    '   {:14s} = {:8.2f} MPa'.format('Modulus', surface_modulus),
    '   {:14s} = {:8.2f}'.format('Poissons ratio', surface_poissons_ratio))

    message("Applying connectivity filter...")
    confilt = vtkbone.vtkboneImageConnectivityFilter()
    confilt.SetInputData(image)
    confilt.Update()
    image = confilt.GetOutput()

    message("Generating mesh...")
    mesher = vtkbone.vtkboneImageToMesh()
    mesher.SetInputData(image)
    mesher.Update()
    mesh = mesher.GetOutput()

    message("Generating material table...")
    E = bone_modulus
    v = bone_poissons_ratio
    material_name = bone_name
    linear_material = vtkbone.vtkboneLinearIsotropicMaterial()
    linear_material.SetYoungsModulus(E)
    linear_material.SetPoissonsRatio(v)
    linear_material.SetName(material_name)

    material_table = vtkbone.vtkboneMaterialTable()
    material_table.AddMaterial(surface_material_id, linear_material)
    material_table.AddMaterial(bone_material_id, linear_material)

    message("Compiling model...")
    # Compile the mesh and material_table into a test base:
    modelConfig = vtkbone.vtkboneApplyTestBase()
    modelConfig.SetInputData(0, mesh)
    modelConfig.SetInputData(1, material_table)

    # Assign material_table properties to the appropriate voxels:
    modelConfig.SetTopConstraintSpecificMaterial(127)
    modelConfig.UnevenTopSurfaceOn()
    modelConfig.UseTopSurfaceMaximumDepthOn()
    modelConfig.SetTopSurfaceMaximumDepth(3.5)

    modelConfig.SetBottomConstraintSpecificMaterial(127)
    modelConfig.UnevenBottomSurfaceOn()
    modelConfig.UseBottomSurfaceMaximumDepthOn()
    modelConfig.SetBottomSurfaceMaximumDepth(3.5)
    modelConfig.Update()

    model = modelConfig.GetOutput()

    # Report model size (bounds):
    message("Model bounds:", (" %.4f" * 6) % model.GetBounds())

    message("Defining displacement boundary conditions...")

    # Initialize the displacement vector:
    e_init = np.array([0, 0, -float(displacement)])
    # Fix the bottom surface nodes completely (i.e. in x, y, and z-directions):
    model.FixNodes('face_z0', 'bottom_fixed')

    # Transform the displacement vector:
    message("Setting boundary conditions...")
    e_trafo = np.dot(np.linalg.inv(rotation), e_init)

    # Apply boundary conditions by components of the displacement vector:
    model.ApplyBoundaryCondition('face_z1', vtkbone.vtkboneConstraint.SENSE_X, e_trafo[0], 'x_moved')
    model.ApplyBoundaryCondition('face_z1', vtkbone.vtkboneConstraint.SENSE_Y, e_trafo[1], 'y_moved')
    model.ApplyBoundaryCondition('face_z1', vtkbone.vtkboneConstraint.SENSE_Z, e_trafo[2], 'z_moved')

    info = model.GetInformation()
    pp_node_sets_key = vtkbone.vtkboneSolverParameters.POST_PROCESSING_NODE_SETS()
    pp_node_sets_key.Append(info, 'face_z1')
    pp_node_sets_key.Append(info, 'face_z0')
    model.AppendHistory("Created with modelgenerator_registered_fe.py version 1.0")

    message("Writing n88model file: ", output_file)
    writer = vtkbone.vtkboneN88ModelWriter()
    writer.SetInputData(model)
    writer.SetFileName(output_file)
    writer.Update()

    message("Done. Have a nice day!")

# Main function
def main():

    description = '''Generates an n88model from 3D registered images.

    If no valid transform file is found, then no transform is applied.

    Authors: Ryan M. Plett and Steven K. Boyd'''

    parser = argparse.ArgumentParser(formatter_class = argparse.RawTextHelpFormatter, prog = 'blmodelgenerator_reg', description = description)
    parser.add_argument('input_file', help = 'Input image file (*.AIM).')
    parser.add_argument('output_file', help = 'Output n88 model file (*.n88model).')
    parser.add_argument('--material_file', help = 'Material property file (*.txt).')
    parser.add_argument('--transform_file', default = 'dummy', help = 'Transformation matrix (*.txt).')
    parser.add_argument('--overwrite', action = 'store_true', help = 'Overwrite existing output.')
    parser.add_argument('--displacement', type = float, default = '0.102', help = 'Displacement boundary condition for registered volume.')
    args = parser.parse_args()

    CreateN88Model(**vars(args))

# Call main function
if __name__ == '__main__':
    main()

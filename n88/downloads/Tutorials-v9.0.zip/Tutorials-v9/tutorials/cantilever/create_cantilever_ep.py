"""Example script for Tutorial: A cantilevered beam with elastoplastic material
   properties

This script creates from scratch a cantilever beam model with an applied force
on the end of the beam. This version uses elastoplastic material properties.

Refer to the FAIM manual for description and use of this example script.

Copyright 2015-2016, Numerics88 Solutions Ltd.

You may freely copy, modify and share this script.
"""

from __future__ import division
import argparse
import numpy
from numpy.core import *
import vtk
import vtkbone
from vtk.util.numpy_support import vtk_to_numpy, numpy_to_vtk

script_version = 3

parser = argparse.ArgumentParser (
    description="""Generate a model for a cantilever with an
applied force to the end of the beam.""")

parser.add_argument ("applied_force", type=float,
   help="The applied force to the end of the beam.")

parser.add_argument ("output_file",
    help="Name for output n88model file.")

args = parser.parse_args()

# Create the image

dims = array((20, 1, 200))  # order: z,y,x
cellmap = ones(dims)
cellmap_vtk = numpy_to_vtk(ravel(cellmap), deep=1, array_type=vtk.VTK_INT)

image = vtk.vtkImageData()
image.SetDimensions(dims[::-1] + 1)   # +1 because these are Point counts, not Cell counts
image.SetSpacing(0.5, 0.5, 0.5)      # 0.5 mm square elements
image.GetCellData().SetScalars(cellmap_vtk)

# Optional: write out image data to examine it

print ("Writing geometry file: beam_image.vti")
writer = vtk.vtkXMLImageDataWriter()
writer.SetInputData(image)
writer.SetFileName("beam_image.vti")
writer.Update()

# Generate a geometrical mesh from the input image

mesh_generator = vtkbone.vtkboneImageToMesh()
mesh_generator.SetInputData(image)
mesh_generator.Update()
mesh = mesh_generator.GetOutput()

# Create a material

material = vtkbone.vtkboneVonMisesIsotropicMaterial()
material.SetName("steel")
material.SetYoungsModulus(2.0E5)  # units are MPa
material.SetPoissonsRatio(0.3)
material.SetYieldStrength(120)   # units are MPa

material_table = vtkbone.vtkboneMaterialTable()
material_table.AddMaterial (1, material)

# Create a model without boundary conditions.

generator = vtkbone.vtkboneApplyTestBase()
generator.SetInputData(0, mesh)
generator.SetInputData(1, material_table)
generator.Update()
model = generator.GetOutput()

# Create the fixed boundary conditions at the base of the beam.
# To obtain a more truely 2D result, no constraint is applied to
# displacements in the _y_ direction.

model.ApplyBoundaryCondition(
    "face_x0",
    vtkbone.vtkboneConstraint.SENSE_X,
    0,
    "fixed_beam_base_x")
model.ApplyBoundaryCondition(
    "face_x0",
    vtkbone.vtkboneConstraint.SENSE_Z,
    0,
    "fixed_beam_base_z")

# Apply a force to the far end of the beam

model.ApplyLoad(
	"face_x1",
	vtkbone.vtkboneConstraint.FACE_X1_DISTRIBUTION,
	vtkbone.vtkboneConstraint.SENSE_Z,
	args.applied_force,
	"end_force")

# Create a convergence set: the displacement of the tip

model.ConvergenceSetFromConstraint("end_force")

# Set the node sets and element sets that will be used for post-processing

info = model.GetInformation()
pp_node_sets_key = vtkbone.vtkboneSolverParameters.POST_PROCESSING_NODE_SETS()
pp_elem_sets_key = vtkbone.vtkboneSolverParameters.POST_PROCESSING_ELEMENT_SETS()
pp_node_sets_key.Append(info, "face_x0")
pp_elem_sets_key.Append(info, "face_x0")
pp_node_sets_key.Append(info, "face_x1")
pp_elem_sets_key.Append(info, "face_x1")

# Update history and log

model.AppendHistory("Created by create_cantilever.py version %s ." % script_version)

model.AppendLog(
"""create_cantilever.py
Cantilever beam model with applied force on far face edge of %s .
Using vtkbone version %s .
""" % (args.applied_force, vtkbone.vtkboneVersion.GetvtkboneVersion()))

# Write an n88model file

print "Writing n88model file:", args.output_file
writer = vtkbone.vtkboneN88ModelWriter()
writer.SetInputData(model)
writer.SetFileName(args.output_file)
writer.Update()

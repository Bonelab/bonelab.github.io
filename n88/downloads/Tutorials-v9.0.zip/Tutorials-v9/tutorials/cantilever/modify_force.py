from __future__ import division
import argparse
import vtk
import vtkbone

script_version = 1

parser = argparse.ArgumentParser (
    description="""Take an existing cantilever model file, and modify the applied force
while leaving any existing solution unmodified. It can thus be used as the starting
value for a solution with the new applied force.""")

parser.add_argument ("input_file",
   help="An existing cantilever model file.")

parser.add_argument ("applied_force", type=float,
   help="The new applied force.")

parser.add_argument ("output_file",
    help="Name for output file.")

args = parser.parse_args()

# Read existing model (including possible solution)

print "Reading n88model file:", args.input_file
reader = vtkbone.vtkboneN88ModelReader()
reader.SetFileName (args.input_file)
reader.Update()
model = reader.GetOutput()

# Delete the old applied force.

model.GetConstraints().RemoveItem("end_force")

# Apply the new force to the far end of the beam.

model.ApplyLoad(
	"face_x1",
	vtkbone.vtkboneConstraint.FACE_X1_DISTRIBUTION,
	vtkbone.vtkboneConstraint.SENSE_Z,
	args.applied_force,
	"end_force")

# Update history and log

model.AppendHistory("Modified modify_force.py version %s ." % script_version)

model.AppendLog(
"""modify_force.py
Changed applied force on far face edge to %s .
Using vtkbone version %s .
""" % (args.applied_force, vtkbone.vtkboneVersion.GetvtkboneVersion()))

# Write an n88model file

print "Writing n88model file:", args.output_file
writer = vtkbone.vtkboneN88ModelWriter()
writer.SetInputData(model)
writer.SetFileName(args.output_file)
writer.Update()

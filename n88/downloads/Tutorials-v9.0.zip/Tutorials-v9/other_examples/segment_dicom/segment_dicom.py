"""
An example vtkbone script for FAIM.

Copyright 2012-2016, Numerics88 Solutions Ltd.

This script demonstrates a simple segmentation of a raw image file.  The
input image consists of density values.  A segmentation is performed
based on a density threshold and connectivity.
"""

import sys
import argparse
import vtk
from numpy.core import *
from vtk.util.numpy_support import vtk_to_numpy, numpy_to_vtk
import vtkbone

parser = argparse.ArgumentParser (
    description="""Segment a DICOM format file and write a VTK Image file.""")

parser.add_argument ("--material_id", type=int, default=127,
    help="Material ID (default: %(default)s)")
parser.add_argument ("--threshold", type=float,
    help="Thresold for segmenting (must be specified)")
parser.add_argument ("--zspacing", type=float,
    help="Set z spacing (cannot always be read from DICOM)")

parser.add_argument ("input")
parser.add_argument ("output")

args = parser.parse_args()

if args.threshold is None:
    print "You must specify a threshold."
    sys.exit(-1)

recursive = True

print "Reading", args.input

reader = vtk.vtkDICOMImageReader()
reader.SetDirectoryName (args.input)
reader.Update()

raw_image = reader.GetOutput()
raw_data = vtk_to_numpy (raw_image.GetPointData().GetScalars())
raw_data.shape = raw_image.GetDimensions()

if args.zspacing:
    spacing = array(raw_image.GetSpacing())
    spacing[2] = args.zspacing
    raw_image.SetSpacing (spacing)

print "Raw data range:", min(raw_data.flat), ",", max(raw_data.flat)

print "Dimensions:", raw_image.GetDimensions()
print "Spacing:", raw_image.GetSpacing()
print "Origin:", raw_image.GetOrigin()

print "Thresholding."
segmented_image = vtk.vtkImageData()
segmented_image.SetScalarTypeToShort()
segmented_image.SetExtent (raw_image.GetExtent())
segmented_image.SetOrigin (raw_image.GetOrigin())
segmented_image.SetSpacing (raw_image.GetSpacing())
segmented_image.AllocateScalars()
segmented_data = vtk_to_numpy (segmented_image.GetPointData().GetScalars())
segmented_data.shape = segmented_image.GetDimensions()
segmented_data[:,:,:] = args.material_id * (raw_data > args.threshold)

print "%d voxels are present after thresholding." % sum(segmented_data > 0)

print "Masking by connectivity"
connectivity_filter = vtkbone.vtkboneImageConnectivityFilter()
connectivity_filter.SetInputData (segmented_image)
connectivity_filter.Update()
segmented_image = connectivity_filter.GetOutput()
segmented_data = vtk_to_numpy (segmented_image.GetPointData().GetScalars())
segmented_data.shape = segmented_image.GetDimensions()

print "%d voxels are present after connectivity filter." % sum(segmented_data > 0)

print "Writing", args.output
writer = vtk.vtkXMLImageDataWriter()
writer.SetInputData (segmented_image)
writer.SetFileName (args.output)
writer.Update()
